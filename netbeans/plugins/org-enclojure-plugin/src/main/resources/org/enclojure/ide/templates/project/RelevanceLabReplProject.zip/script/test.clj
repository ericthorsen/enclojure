(use 'circumspec.runner)
(run-tests-and-exit)
